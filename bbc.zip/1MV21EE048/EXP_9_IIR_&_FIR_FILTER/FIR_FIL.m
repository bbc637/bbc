clc;
clear all;
b=[];
a=[1];
freqz(b,a);
ylim([-30,5]);