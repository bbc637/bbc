clc;
clear all;
N=38;
M=N+1;
wc=0.35
win=[0.5;ones(M-2,1);0.5];
b=fir1(N,wc,win);
[H,w]=freqz(b,1);
plot(w/pi,mag2db(abs(H)));
title('lowpass filter with wc=0.35&N=38');
xlabel('normalized frewuency');
ylabel('magnitude in dB');
