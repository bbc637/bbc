clc;
clear all;
x1=[1 2 -1 3 5]
x2=[1 -1]
L=length(x1);
M=length(x2);
N=L+M-1;
x1=[x1 zeros(1,N-L)];
x2=[x2 zeros(1,N-M)];
x1=fft(x1,N);
x2=fft(x2,N);
y=x1.*x2;
y=ifft(y,N);
disp(y);

