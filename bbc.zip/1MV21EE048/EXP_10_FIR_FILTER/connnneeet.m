clc;
clear all;
x1=input('enter the sequence x1(n):');
x2=input('enter the sequence x2(n):');
L=length(x1);
M=length(x2);
N=L+M-1;
if L<M
    x1=[x1 zeros(1,N-L)];
else
    x2=[x2 zeros(1,N-M)];
end
disp(x1);
disp(x2);
Y1=fft(x1,N);
Y2=fft(x2,N);
Y=Y1.*Y2;
y=ifft(Y,N);
disp(y);
z=conv(Y1,Y2);
disp(z);