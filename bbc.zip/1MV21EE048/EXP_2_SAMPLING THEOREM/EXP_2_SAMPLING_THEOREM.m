clc;
clear all; 
fm=input('Enter the Maximum Frequnecy- ');
fs=input('Enter the Sampling Frequency- ');
t=0:0.001:10/fm;
x=cos(2*pi*fm*t);
subplot(3,1,1)
plot(t,x);
title('Continous Sampling  Signal');
xlabel('Time(s)');
ylabel ('Amplitude');
n=0:1/fs:10/fm;
y=cos(2*pi*fm*n);
subplot(3,1,2)
stem(n,y);
title('Sampled Signal');
xlabel('N');
ylabel ('Amplitude');
X=interp(y,1);
subplot(3,1,3)
plot(n,X)
title('Regenerated Signal');
xlabel('Time(s)');
ylabel ('Amplitude');
L=length(X);
X1=fft(X);
X2=abs(X1)/L;
X3=2*X2(1:L/2);
f=fs*(0:L/2-1)/L;
figure;
plot(f,X3);
title('Single Sides Frequency Domain Signal')
xlabel('f')
ylabel('|X3(f)|');