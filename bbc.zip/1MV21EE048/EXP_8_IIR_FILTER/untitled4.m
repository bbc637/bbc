clc;
clear all;

f = 2000;    % Sampling frequency (Hz)
fp = 700;    % Passband edge frequency (Hz)
fs = 500;    % Stopband edge frequency (Hz)

% Calculate digital frequencies
wp = (2*pi*fp)/f;   % Digital passband edge frequency (radians)
ws = (2*pi*fs)/f;   % Digital stopband edge frequency (radians)

% Specifications
ap = 1;    % Passband ripple (dB)
as = 32;   % Stopband attenuation (dB)

% Convert to analog frequencies
op = (2*f)*tan(wp/2);   % Analog passband edge frequency (Hz)
os = (2*f)*tan(ws/2);   % Analog stopband edge frequency (Hz)

op1 = 1;    % Analog prototype cutoff frequency (normalized)

% Calculate filter order and cutoff frequency
[N, oc] = cheb1ord(op1, os/op, ap, as, 's');

% Design Chebyshev Type I filter
[b, a] = cheby1(N, ap, op1, 's');

% Convert low-pass to high-pass using bilinear transformation
[bt, at] = lp2hp(b, a, op*op1);

% Bilinear transform to get digital filter coefficients
[bz, az] = bilinear(bt, at, f);

% Compute frequency response
[h, w] = freqz(bz, az, 512, f);  % Specify 512 points for frequency response

% Plot frequency response in dB
plot(w/(2*pi), mag2db(abs(h)));  % Convert radians to Hz for x-axis
ylim([-30, 5]);
grid on;
title('High Pass CHEBYSHEV BILLINEAR TRANSFORMATION TECHNIQUE');
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
