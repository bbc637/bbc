clc;
clear all;
x=input('Enter the original sequnce= ')
L=length(x);
n=-(L-1):(L-1);
x11=zeros(1,2*L-1);
x22=zeros(1,2*L-1);
k=L;
for i=1:L;
    x11(k)=x(i);
    k=k+1;
end
k=L;
for i=L:2*L-1
    x22(k)=x11(i)
    k=k-1;
end
disp(x22)
subplot(4,1,1)
stem(n,x11)
subplot(4,1,2)
stem(n,x22)
y=(x11+x22)/2;
z=(x11-x22)/2;
disp(y);
disp(z);
subplot(4,1,3)
stem(n,y)
subplot(4,1,4)
stem(n,z)