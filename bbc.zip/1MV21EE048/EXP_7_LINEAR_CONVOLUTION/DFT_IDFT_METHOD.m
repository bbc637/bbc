clc;
clear all;
x1=input('Enter the 1st Sequence= ');
x2=input('Enter the 2nd Sequence= ');
L=length(x1);
M=length(x2);
N=L+M-1;
x1=[x1 zeros(1,(N-L))];
x2=[x2 zeros(1,(N-M))];
X1=fft(x1,N);
X2=fft(x2,N);
Y=X1.*X2;
y=ifft(Y,N);
disp(y)