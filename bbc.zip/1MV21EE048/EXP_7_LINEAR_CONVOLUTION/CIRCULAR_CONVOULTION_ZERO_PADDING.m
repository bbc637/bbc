clc;
clear all;
x1=input('Enter the 1st Sequence= ');
x2=input('Enter the 2nd Sequence= ');
L=length(x1);
M=length(x2);
N=L+M-1;