clc;
clear all;
x=input('Enter the given sequence= ');
N=length(x);
X=zeros(1,N);
for k=1:N
   for n=1:N
       X(k)=X(k) + x(n)*exp(-1i*2*pi*(k-1)*(n-1)/N);
   end
end
mag=abs(X);
for k=1:N
    phase(k)=atan(imag(X(k))/real(X(k)));
end
X1=fft(x,N);
disp(X);
disp(X1);

n=0:N-1;
subplot(2,1,1)
stem(n,mag);
title('Magnitude Plot')
xlabel('n')
ylabel('Magnitude')

subplot(2,1,2)
stem(n,phase);
title('Phase Plot')
xlabel('n')
ylabel('Phase of (x)')