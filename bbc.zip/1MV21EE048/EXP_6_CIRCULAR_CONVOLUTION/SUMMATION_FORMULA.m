clc;
clear all;
x1=input('Enter the 1st Sequence= ');
x2=input('Enter the 2nd Sequence= ');
L=length(x1);
M=length(x2);
N=max(L,M);
if L<N
    x1=[x1 zeros(1,N-L)];
else
     x2=[x2 zeros(1,N-M)];
end
for i=1:N
    if i==1
        x3(i)=x2(i);
    else 
        x3(i)=x2(N-i+2);
    end
end

for n=1:N
    y(n)=sum(x1'.*circshift(x3',n-1));
end

y1=cconv(x1,x2,N);
disp(y);
disp(y1);