clc;
clear all;
x1=input('Enter the 1st Sequence= ');
x2=input('Enter the 2nd Sequence= ');
L=length(x1);
M=length(x2);
N=max(L,M);
if L<N
    x1=[x1 zeros(1,N-L)];
else
     x2=[x2 zeros(1,N-M)];
end
for i=1:N
    A(:,i)=circshift(x1',i-1);
end
y=A*x2';
disp(y);