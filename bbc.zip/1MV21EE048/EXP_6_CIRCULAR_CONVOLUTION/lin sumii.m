clc;
clear all;
x1=input('Enter the 1st Sequence= ');
x2=input('Enter the 2nd Sequence= ');
L=length(x1);
M=length(x2);
N=L+M-1;
x11=zeros(1, 2*L-1);
x22=zeros(1, 2*L-1);
K=L;
for i=1:L
    x11(K)=x1(i);
    K=K+1;
end
K=L;
for i=1:M
    x22(K)=x2(i);
    K=K-1;
end

for n=1:N
    y(n)=sum(x11'.*circshift(x22',n-1));
end
y1=conv(x1,x2);
disp(y);
disp(y1);